# Travel_Website
Responsive Travel website design using HTML, CSS, and JS.

Header/navbar contains toggle menu bar effect, search bar, and login/registeration form.
Home section contains video slider using JS
Book, Packages, Seevices, Gallery, Review, Contact & Footer are made using flexbox.
Gallery has hover section effect.
Review & Brand section with touch slider.

Furute Updates

Adding chat bot.
